package Fundamentos;
/**
 * Essa classe representa... JAVADOC
 * @author Leonardo <@email.com>
 * @since JDK1.0
 * @see
 */

public class PrimeiroPrograma 
{
	// Uma sentença de códico termina com ;
	// Mais um comentário...
	// Fim
	/*
	 * Linha 1 
	 * Linha2...
	 */
	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
		System.out.println("Hello world!!!"); // Aqui também funciona
	}
}
