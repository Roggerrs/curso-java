package Fundamentos;

public class PrimitivosVsObjeto {
	public static void main(String[] args) {
	
		String s = new String ("texto"); 
		s.toUpperCase(); 
		
		// Wrappers são a versão objeto dos tipos primitos!
		
		int a = 123; 
	  System.out.println(a); 
	  
	  
		
	}

}
