package classe;

public class Trauma {
	
	 // int a = 3;  // atributos instancia.
	static int  b = 4; // atributos estáticos. 
	
	public static void main(String[] args) {
		
	// PrimeiroTrauma p = new PrimeiroTrauma();
		
		// System.out.println(p.a);
		
		System.out.println(b);
	}

}
