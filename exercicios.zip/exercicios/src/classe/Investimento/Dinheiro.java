package classe.Investimento;

public class Dinheiro {

	String investidor; 
	double compostos;
	
	Dinheiro(String investidor, double compostos) {
		this.investidor = investidor;
		this.compostos = compostos;  
	}
	
}
