package oo.heranca.desafio;

public interface Exportivo {
	
	public abstract void ligarTurbo(); 
	void desligarTurbo();
	
	

}
