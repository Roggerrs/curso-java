package controle;

public class Desafio {
public static void main(String[] args) {
	
	double nota = 1.3;
	
	if(nota >=9.0) // Não usa ; porque pode atrapalhar a lógica  do código, executando diferente, mas tem uma exceção.
	
	{
		System.out.println("Quandro de Honra!");
		System.out.println("Você é fera!!!");
	}
}
}
