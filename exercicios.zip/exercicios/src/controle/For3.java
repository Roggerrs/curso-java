package controle;

public class For3 {
public static void main(String[] args) {
	
	// for(int i = 0; i < 10; i++) Neste exemplo a variável vai estar apenas dispnível no laço For.
	
	
	//for(int i  = 0; i < 10; i++) {
	//	System.out.println(i);
//	}
//	int i = 0;
//	System.out.println("Saiu do for...");
//	System.out.println(i);
	
	
	for(int i = 0; i < 10; i++) {
		for(int j = 0; j <10; j++) 	{
			System.err.printf("%d %d]", i, j);
		}

System.out.println();
	}
}
}
