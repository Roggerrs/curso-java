package controle;

public class For1 {
	public static void main(String[] args) {

	//	int contador = 0;
	//	while(contador <= 20) {
	//		System.out.printf("i = %d\n", contador);
	//		contador +=2;
	//	}
		
		for(int contador = 1 ; contador <= 10; contador ++) {
			System.out.printf("i = %d\n", contador);	
		}
		int x = 1;
	    for(; x < 10;) {
	    	System.out.println("x = " +x);
	    	x++;
	    }
	    // Neste exemplo ele nunca vai parar de executar. Laço infinito
	   // for(;true;) {
	   // System.out.println("Fim!");
	    }
	}


