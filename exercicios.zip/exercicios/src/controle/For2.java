package controle;

public class For2 {
	public static void main(String[] args) {
		
		for(int calculo = 10 ; calculo >= 0; calculo -=2) { // multiplicar em 2 em 2.
			System.out.printf("Resultado = %d\n" , calculo);
			
		}
		
		
	}
// decrescente 10 até 0 acabou em 2 em 2
}
