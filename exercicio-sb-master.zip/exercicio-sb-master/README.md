# exercicio-sb
Exercicio Spring Boot da Cod3r

Exercicio de Spring Boot do treinamento da Cod3r

Foi adicionado uma funcionalidade extra como teste para o primeiro webservice simulando uma calculadora com operações de soma e subtração passando parametros através da url
